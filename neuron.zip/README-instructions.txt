Here are some simple tips and instructions on how to best use your new QR code:

Scan-Facebook-8.5x11-Print.pdf - Best for instant printing on standard 8.5x11 paper.

Scan-Facebook-Badge-Red.jpg - Great for posters, flyers, and other print materials.

Scan-Facebook-Badge-Gray.jpg - Great for posters, flyers, and other print materials.

Scan-Facebook-Badge-Red.png - Great for blogs, social networks, videos, and other digital media.

Scan-Facebook-Badge-Gray.png - Great for blogs, social networks, videos, and other digital media.

Scan-Facebook-Color.jpg - Great for posters, flyers, and other print materials.

Scan-Facebook-Gray.jpg - Great for posters, flyers, and other print materials.

Scan-Facebook-Color.png - Great for blogs, social networks, videos, and other digital media.

Scan-Facebook-Gray.png - Great for blogs, social networks, videos, and other digital media.

Scan-Facebook-Vector-Set.eps - We've included your code in a vector format to give you complete freedom and control over customization. Great for large signs, embroidery, custom designs, and really whatever you can imagine!

Questions? We'd love to help you out. You can reach us at help@scan.me
Check out other great examples and best practices in our gallery : http://scan.me/gallery